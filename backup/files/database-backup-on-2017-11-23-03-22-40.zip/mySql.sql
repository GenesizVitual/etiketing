#
# TABLE STRUCTURE FOR: beli_tiket
#

DROP TABLE IF EXISTS `beli_tiket`;

CREATE TABLE `beli_tiket` (
  `id_bt` int(11) NOT NULL AUTO_INCREMENT,
  `id_klien` int(11) NOT NULL,
  `tgl_beli` datetime NOT NULL,
  `id_jt` int(11) NOT NULL,
  `qty` int(20) NOT NULL,
  `jumlah_total` int(11) NOT NULL,
  `status` int(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_bt`),
  KEY `beli_tiket_ibfk_1` (`id_klien`),
  CONSTRAINT `beli_tiket_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: deposit
#

DROP TABLE IF EXISTS `deposit`;

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_depos` datetime NOT NULL,
  `id_klien` int(11) NOT NULL,
  `jumlah_depos` int(50) unsigned NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_klien` (`id_klien`),
  CONSTRAINT `deposit_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenis_kapal
#

DROP TABLE IF EXISTS `jenis_kapal`;

CREATE TABLE `jenis_kapal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kapal` varchar(200) NOT NULL,
  `kapasitas_penumpang` int(20) NOT NULL,
  `thn_pembuatan` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenis_retribusi
#

DROP TABLE IF EXISTS `jenis_retribusi`;

CREATE TABLE `jenis_retribusi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_retribusi` varchar(300) NOT NULL,
  `singkatan` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenis_tarif
#

DROP TABLE IF EXISTS `jenis_tarif`;

CREATE TABLE `jenis_tarif` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_jt` smallint(11) NOT NULL,
  `jenis_tarif` varchar(100) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga` int(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: kabupaten
#

DROP TABLE IF EXISTS `kabupaten`;

CREATE TABLE `kabupaten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kabupaten` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: klien
#

DROP TABLE IF EXISTS `klien`;

CREATE TABLE `klien` (
  `id_klien` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(100) NOT NULL,
  `nama_klien` varchar(200) NOT NULL,
  `kode_barcode` varchar(500) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kel` enum('Pria','Wanita') NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `rt` varchar(20) NOT NULL,
  `rw` varchar(20) NOT NULL,
  `desa` varchar(50) NOT NULL,
  `kec` varchar(50) NOT NULL,
  `kab` varchar(50) NOT NULL,
  `pekerjaan` varchar(200) NOT NULL,
  `warga_negara` enum('WNI','WNA') NOT NULL,
  `status` enum('kawin','belum kawin') NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_message` tinyint(1) NOT NULL COMMENT '0=belum proses, 1=lagi proses',
  PRIMARY KEY (`id_klien`),
  UNIQUE KEY `nik` (`nik`),
  KEY `user_id` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pelabuhan
#

DROP TABLE IF EXISTS `pelabuhan`;

CREATE TABLE `pelabuhan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelabuhan` varchar(200) NOT NULL,
  `alamat_pel` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: registrasi_kartu
#

DROP TABLE IF EXISTS `registrasi_kartu`;

CREATE TABLE `registrasi_kartu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_reg` datetime NOT NULL,
  `id_klien` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_jt` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_klien` (`id_klien`),
  CONSTRAINT `registrasi_kartu_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: rute
#

DROP TABLE IF EXISTS `rute`;

CREATE TABLE `rute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kapal_id` int(11) NOT NULL,
  `rute` varchar(200) NOT NULL,
  `jumlah_rute` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: total_deposit
#

DROP TABLE IF EXISTS `total_deposit`;

CREATE TABLE `total_deposit` (
  `id_tdepo` int(11) NOT NULL AUTO_INCREMENT,
  `id_klien` int(11) NOT NULL,
  `total_deposit` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id_tdepo`),
  KEY `id_klien` (`id_klien`),
  CONSTRAINT `total_deposit_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(200) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` smallint(5) NOT NULL COMMENT '0= Super admin, 1=Depositor/Register, 2=Retributor, 3=Org Dishub',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('1', 'Fandi', '', 'admin', '1f32aa4c9a1d2ea010adcf2348166a04', '0');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('2', 'Deker', '', 'User 1', '1f32aa4c9a1d2ea010adcf2348166a04', '1');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('3', 'La Ode', '', 'User 23', '1f32aa4c9a1d2ea010adcf2348166a04', '2');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('4', 'Loka', '', 'Kias', '1f32aa4c9a1d2ea010adcf2348166a04', '3');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('5', 'La Ode', '199219928182773', 'Boka', '1f32aa4c9a1d2ea010adcf2348166a04', '4');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('6', 'Wa Ode', '1929239198238', 'Moana', '1f32aa4c9a1d2ea010adcf2348166a04', '5');


