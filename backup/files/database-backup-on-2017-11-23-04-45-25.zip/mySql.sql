#
# TABLE STRUCTURE FOR: beli_tiket
#

DROP TABLE IF EXISTS `beli_tiket`;

CREATE TABLE `beli_tiket` (
  `id_bt` int(11) NOT NULL AUTO_INCREMENT,
  `id_klien` int(11) NOT NULL,
  `tgl_beli` datetime NOT NULL,
  `id_jt` int(11) NOT NULL,
  `qty` int(20) NOT NULL,
  `jumlah_total` int(11) NOT NULL,
  `status` int(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_bt`),
  KEY `beli_tiket_ibfk_1` (`id_klien`),
  CONSTRAINT `beli_tiket_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: deposit
#

DROP TABLE IF EXISTS `deposit`;

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_depos` datetime NOT NULL,
  `id_klien` int(11) NOT NULL,
  `jumlah_depos` int(50) unsigned NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_klien` (`id_klien`),
  CONSTRAINT `deposit_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jenis_kapal
#

DROP TABLE IF EXISTS `jenis_kapal`;

CREATE TABLE `jenis_kapal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kapal` varchar(200) NOT NULL,
  `kapasitas_penumpang` int(20) NOT NULL,
  `thn_pembuatan` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `jenis_kapal` (`id`, `nama_kapal`, `kapasitas_penumpang`, `thn_pembuatan`) VALUES ('1', 'Kapal 1', '400', '2015');
INSERT INTO `jenis_kapal` (`id`, `nama_kapal`, `kapasitas_penumpang`, `thn_pembuatan`) VALUES ('2', 'Kapal 2', '200', '2012');
INSERT INTO `jenis_kapal` (`id`, `nama_kapal`, `kapasitas_penumpang`, `thn_pembuatan`) VALUES ('4', 'Kapal Katinting', '25', '2012');


#
# TABLE STRUCTURE FOR: jenis_retribusi
#

DROP TABLE IF EXISTS `jenis_retribusi`;

CREATE TABLE `jenis_retribusi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_retribusi` varchar(300) NOT NULL,
  `singkatan` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('1', 'Jasa Tanda Masuk Pelabuhan', 'JTMP');
INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('2', 'Jasa Pemeliharaan Dermaga Bagi Kendaaan Yang Menyebrang', 'JPDK');
INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('3', 'Jasa Timbangan Kendaraan Bermotor', 'JTKB');
INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('4', 'Jasa Penumpukan Barang', 'JPB');
INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('5', 'Tarif Sewa Tanah Dan Bangunan/Ruangan', 'TSTB');
INSERT INTO `jenis_retribusi` (`id`, `jenis_retribusi`, `singkatan`) VALUES ('6', 'Tarif Sewa Pemberitahuan Muatan Kapal', 'SPMK');


#
# TABLE STRUCTURE FOR: jenis_tarif
#

DROP TABLE IF EXISTS `jenis_tarif`;

CREATE TABLE `jenis_tarif` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_jt` smallint(11) NOT NULL,
  `jenis_tarif` varchar(100) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga` int(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `jenis_tarif` (`id`, `id_jt`, `jenis_tarif`, `satuan`, `harga`) VALUES ('1', '1', 'Penumpang/Pengantar/Penjemput', 'Per Orang', '3000');
INSERT INTO `jenis_tarif` (`id`, `id_jt`, `jenis_tarif`, `satuan`, `harga`) VALUES ('2', '1', 'Pas Bulanan/Orang/Karyawan', 'Per Orang', '25000');
INSERT INTO `jenis_tarif` (`id`, `id_jt`, `jenis_tarif`, `satuan`, `harga`) VALUES ('3', '1', 'Pas Bulanan Kendaraan Roda Empat', 'Per Unit/Bukan', '30000');
INSERT INTO `jenis_tarif` (`id`, `id_jt`, `jenis_tarif`, `satuan`, `harga`) VALUES ('4', '1', 'Pas Masuk Kendaraan/Sekali Lewat Kendaraa Gol. I', 'Per Masuk', '2500');


#
# TABLE STRUCTURE FOR: kabupaten
#

DROP TABLE IF EXISTS `kabupaten`;

CREATE TABLE `kabupaten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kabupaten` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `kabupaten` (`id`, `nama_kabupaten`) VALUES ('1', 'Kota Bau Bau');
INSERT INTO `kabupaten` (`id`, `nama_kabupaten`) VALUES ('2', 'Kota Kendari');


#
# TABLE STRUCTURE FOR: klien
#

DROP TABLE IF EXISTS `klien`;

CREATE TABLE `klien` (
  `id_klien` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(100) NOT NULL,
  `nama_klien` varchar(200) NOT NULL,
  `kode_barcode` varchar(500) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kel` enum('Pria','Wanita') NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `rt` varchar(20) NOT NULL,
  `rw` varchar(20) NOT NULL,
  `desa` varchar(50) NOT NULL,
  `kec` varchar(50) NOT NULL,
  `kab` varchar(50) NOT NULL,
  `pekerjaan` varchar(200) NOT NULL,
  `warga_negara` enum('WNI','WNA') NOT NULL,
  `status` enum('kawin','belum kawin') NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read_message` tinyint(1) NOT NULL COMMENT '0=belum proses, 1=lagi proses',
  PRIMARY KEY (`id_klien`),
  UNIQUE KEY `nik` (`nik`),
  KEY `user_id` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `klien` (`id_klien`, `nik`, `nama_klien`, `kode_barcode`, `tempat_lahir`, `tgl_lahir`, `jenis_kel`, `alamat`, `rt`, `rw`, `desa`, `kec`, `kab`, `pekerjaan`, `warga_negara`, `status`, `id_user`, `created_at`, `read_message`) VALUES ('1', '239238172348192', 'Masmuddin', 'PLU-20171113-7240', 'Kendari', '2017-11-13', 'Pria', 'Jln. UHO', '2333', '2333', 'asdfgh', 'asedfghjkgdsdfghjkjhgfdd', 'ddfs', 'Karyawan Swasta', 'WNI', 'kawin', '2', '2017-11-17 07:30:53', '0');
INSERT INTO `klien` (`id_klien`, `nik`, `nama_klien`, `kode_barcode`, `tempat_lahir`, `tgl_lahir`, `jenis_kel`, `alamat`, `rt`, `rw`, `desa`, `kec`, `kab`, `pekerjaan`, `warga_negara`, `status`, `id_user`, `created_at`, `read_message`) VALUES ('2', '2354895482457849', 'Wa Ode Rina', 'PLU-20171115-6569', 'Kendari', '2017-11-15', 'Wanita', 'Jl. HEA Mokodompit', '534', '5673', 'Mataiwoi', 'Wau wau', 'Kendari', 'Karyawan Swasta', 'WNI', 'kawin', '2', '2017-11-18 02:14:15', '0');
INSERT INTO `klien` (`id_klien`, `nik`, `nama_klien`, `kode_barcode`, `tempat_lahir`, `tgl_lahir`, `jenis_kel`, `alamat`, `rt`, `rw`, `desa`, `kec`, `kab`, `pekerjaan`, `warga_negara`, `status`, `id_user`, `created_at`, `read_message`) VALUES ('3', '123232424242', 'Anwar ', 'PLU-20101010-3358', 'Raha', '2010-10-10', 'Pria', 'Jl. La Korumba', '09', '09', 'Wanggu', 'Kadia', 'RAha', 'Nelayan', 'WNI', 'kawin', '1', '2017-11-21 08:53:03', '0');
INSERT INTO `klien` (`id_klien`, `nik`, `nama_klien`, `kode_barcode`, `tempat_lahir`, `tgl_lahir`, `jenis_kel`, `alamat`, `rt`, `rw`, `desa`, `kec`, `kab`, `pekerjaan`, `warga_negara`, `status`, `id_user`, `created_at`, `read_message`) VALUES ('4', '2323323', 'La Rakuti', 'PLU-19901105-2162', 'Kendari', '1990-11-05', 'Pria', 'Jl. Sorumba', '09', '90', 'Rahandouna', 'Puwatu', 'Kendari', 'Dosen', 'WNI', 'kawin', '1', '2017-11-22 02:56:01', '0');


#
# TABLE STRUCTURE FOR: pelabuhan
#

DROP TABLE IF EXISTS `pelabuhan`;

CREATE TABLE `pelabuhan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelabuhan` varchar(200) NOT NULL,
  `alamat_pel` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `pelabuhan` (`id`, `nama_pelabuhan`, `alamat_pel`) VALUES ('1', 'Pelabuhan Bau Bau', 'Jln .....');
INSERT INTO `pelabuhan` (`id`, `nama_pelabuhan`, `alamat_pel`) VALUES ('2', 'Pelabuhan Kendari', 'Jln ......');


#
# TABLE STRUCTURE FOR: registrasi_kartu
#

DROP TABLE IF EXISTS `registrasi_kartu`;

CREATE TABLE `registrasi_kartu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_reg` datetime NOT NULL,
  `id_klien` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_jt` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_klien` (`id_klien`),
  CONSTRAINT `registrasi_kartu_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `registrasi_kartu` (`id`, `tgl_reg`, `id_klien`, `id_user`, `id_jt`) VALUES ('1', '2017-11-17 07:33:41', '1', '2', '3');
INSERT INTO `registrasi_kartu` (`id`, `tgl_reg`, `id_klien`, `id_user`, `id_jt`) VALUES ('2', '2017-11-18 02:14:38', '2', '2', '3');
INSERT INTO `registrasi_kartu` (`id`, `tgl_reg`, `id_klien`, `id_user`, `id_jt`) VALUES ('3', '2017-11-21 09:00:10', '3', '1', '3');
INSERT INTO `registrasi_kartu` (`id`, `tgl_reg`, `id_klien`, `id_user`, `id_jt`) VALUES ('4', '2017-11-22 02:56:42', '4', '1', '3');


#
# TABLE STRUCTURE FOR: rute
#

DROP TABLE IF EXISTS `rute`;

CREATE TABLE `rute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kapal_id` int(11) NOT NULL,
  `rute` varchar(200) NOT NULL,
  `jumlah_rute` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `rute` (`id`, `kapal_id`, `rute`, `jumlah_rute`) VALUES ('1', '1', 'Kendari - bau bau', '0');
INSERT INTO `rute` (`id`, `kapal_id`, `rute`, `jumlah_rute`) VALUES ('2', '1', 'Bau bau - Kendari', '0');
INSERT INTO `rute` (`id`, `kapal_id`, `rute`, `jumlah_rute`) VALUES ('3', '2', 'Kendari - Raha', '0');


#
# TABLE STRUCTURE FOR: total_deposit
#

DROP TABLE IF EXISTS `total_deposit`;

CREATE TABLE `total_deposit` (
  `id_tdepo` int(11) NOT NULL AUTO_INCREMENT,
  `id_klien` int(11) NOT NULL,
  `total_deposit` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id_tdepo`),
  KEY `id_klien` (`id_klien`),
  CONSTRAINT `total_deposit_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id_klien`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `total_deposit` (`id_tdepo`, `id_klien`, `total_deposit`) VALUES ('15', '1', '170500');
INSERT INTO `total_deposit` (`id_tdepo`, `id_klien`, `total_deposit`) VALUES ('16', '2', '376500');
INSERT INTO `total_deposit` (`id_tdepo`, `id_klien`, `total_deposit`) VALUES ('17', '4', '500000');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(200) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` smallint(5) NOT NULL COMMENT '0= Super admin, 1=Depositor/Register, 2=Retributor, 3=Org Dishub',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('1', 'Fandi', '', 'admin', '1f32aa4c9a1d2ea010adcf2348166a04', '0');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('2', 'Deker', '', 'User 1', '1f32aa4c9a1d2ea010adcf2348166a04', '1');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('3', 'La Ode', '', 'User 23', '1f32aa4c9a1d2ea010adcf2348166a04', '2');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('4', 'Loka', '', 'Kias', '1f32aa4c9a1d2ea010adcf2348166a04', '3');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('5', 'La Ode', '199219928182773', 'Boka', '1f32aa4c9a1d2ea010adcf2348166a04', '4');
INSERT INTO `user` (`id`, `nama_user`, `nip`, `username`, `password`, `level`) VALUES ('6', 'Wa Ode', '1929239198238', 'Moana', '1f32aa4c9a1d2ea010adcf2348166a04', '5');


